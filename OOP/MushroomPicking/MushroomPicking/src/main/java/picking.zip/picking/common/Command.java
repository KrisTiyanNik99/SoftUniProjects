package picking.common;

public enum Command {

    AddPlace,
    AddPicker,
    StartPicking,
    GetStatistics,
    Exit
}
