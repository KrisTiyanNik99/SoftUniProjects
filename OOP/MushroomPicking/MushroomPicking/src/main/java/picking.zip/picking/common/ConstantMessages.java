package picking.common;

public class ConstantMessages {

    public static final String PLACE_ADDED = "Place %s added.";

    public static final String PICKER_ADDED = "%s %s added.";

    public static final String PLACE_VISITED = "Place %s was visited.";
}
