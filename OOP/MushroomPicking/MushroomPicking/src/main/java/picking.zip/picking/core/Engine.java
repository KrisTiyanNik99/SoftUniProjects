package picking.core;

public interface Engine extends Runnable {
}
